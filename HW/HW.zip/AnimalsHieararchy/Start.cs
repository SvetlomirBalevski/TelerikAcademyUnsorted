﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsHieararchy
{
    class Start
    {
        static void Main()
        {
            List<Animal> Animals = new List<Animal>();
            Dog peshoTheDog = new Dog(12, "Pesho",Sex.Male);

        }
    }
}
