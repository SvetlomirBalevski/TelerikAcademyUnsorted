﻿namespace School
{
    class Start
    {
        static void Main()
        {

        }
    }
}
