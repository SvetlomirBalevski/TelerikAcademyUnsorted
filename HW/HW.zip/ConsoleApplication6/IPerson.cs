﻿namespace School
{
    public interface IPerson
    {
         int Age { get; set; }
         string Name { get; }
    }
}
