﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Academy.Models.CustomClasses
{
    public interface IResources
    {
        string Url { get; set; }
        string Name { get; set; }
    }
}
