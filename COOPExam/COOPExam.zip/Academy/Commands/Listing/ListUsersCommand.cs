﻿using Academy.Commands.Contracts;
using Academy.Models.Contracts;
using Academy.Models.CustomClasses;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System;

namespace Academy.Commands.Listing
{
    public class ListUsersCommand
    {
    }
}
